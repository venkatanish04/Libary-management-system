package com.aarif1419.eduvault;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduvaultApplicationTests {

	@Test
	void contextLoads() {
	}

}
