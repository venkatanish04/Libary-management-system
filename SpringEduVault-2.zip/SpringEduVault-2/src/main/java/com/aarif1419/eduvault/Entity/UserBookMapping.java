package com.aarif1419.eduvault.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "user_book_mapping", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"user_id", "book_id"}),
    @UniqueConstraint(columnNames = {"oauth_user_id", "book_id"})
})
public class UserBookMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = true)
    private User user;

    @ManyToOne
    @JoinColumn(name = "oauth_user_id", nullable = true)
    private OauthUsers oauthUser;

    @ManyToOne
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    // Constructors, getters, setters, etc.
    public UserBookMapping() {
    }

    public UserBookMapping(User user, OauthUsers oauthUser, Book book) {
        this.user = user;
        this.oauthUser = oauthUser;
        this.book = book;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public OauthUsers getOauthUser() {
        return oauthUser;
    }

    public void setOauthUser(OauthUsers oauthUser) {
        this.oauthUser = oauthUser;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }
}

