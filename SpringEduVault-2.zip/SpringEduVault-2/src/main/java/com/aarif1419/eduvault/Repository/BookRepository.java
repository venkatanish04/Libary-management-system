package com.aarif1419.eduvault.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aarif1419.eduvault.Entity.Book;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {

    List<Book> findByTitleContaining(String title);

    List<Book> findByCategory(String category);

    List<Book> findByTitleContainingAndCategory(String title, String category);
}

