package com.aarif1419.eduvault.Controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;
import com.aarif1419.eduvault.Entity.Book;
import com.aarif1419.eduvault.Entity.OauthUsers;
import com.aarif1419.eduvault.Entity.User;
import com.aarif1419.eduvault.Repository.OauthUsersRepository;
import com.aarif1419.eduvault.Repository.UserRepository;
import com.aarif1419.eduvault.Service.BookService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OauthUsersRepository oauthUsersRepository;


    // @GetMapping("/getUserBooks")
    // public ResponseEntity<List<Book>> getUserBooks(@RequestParam() String username){
    //     User user = userRepository.findByUsername(username);
    //     List<Book> books = bookService.getBooksForUser(user);

    //     return ResponseEntity.ok(books);
    // }

    // @GetMapping("/getOauthUserBooks")
    // public ResponseEntity<List<Book>> getOauthUserBooks(@RequestParam() String username){
    //     OauthUsers oauthuser = oauthUsersRepository.findByUsername(username);
    //     List<Book> books = bookService.getBooksForOAuthUser(oauthuser);

    //     return ResponseEntity.ok(books);
    // }

    // Endpoint to get books with optional title search and category filter
    @GetMapping("/get")
    public ResponseEntity<List<Book>> getBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String category)
             {

        List<Book> books = bookService.findBooks(title, category);
        return ResponseEntity.ok(books);
    }

    @PostMapping("/add")
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book savedBook = bookService.addBook(book);
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);  // Returns the saved book with HTTP 201 Created
    }

    @PostMapping("/addBulk")
    public ResponseEntity<?> addBulkBook(@RequestBody List<Book> books) {
        List<Book> savedBooks = bookService.addBulkBook(books);
        return new ResponseEntity<>(savedBooks, HttpStatus.CREATED);  // Returns the saved books with HTTP 201 Created
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        try {
            Book book = bookService.updateBook(id, updatedBook);
            return new ResponseEntity<>(book, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);  // Return 404 if book is not found
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        try {
            bookService.deleteBook(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // Return 204 No Content on successful deletion
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // Return 404 if book is not found
        }
    }
    
}

