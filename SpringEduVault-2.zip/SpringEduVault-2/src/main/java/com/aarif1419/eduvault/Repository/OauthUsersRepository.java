package com.aarif1419.eduvault.Repository;

import org.springframework.data.repository.CrudRepository;

import com.aarif1419.eduvault.Entity.OauthUsers;


public interface OauthUsersRepository extends CrudRepository<OauthUsers, Integer> {
    OauthUsers findByEmail(String email);
    OauthUsers findByUsername(String username);

}
