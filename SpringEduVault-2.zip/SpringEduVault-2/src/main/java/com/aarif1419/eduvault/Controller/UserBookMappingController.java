package com.aarif1419.eduvault.Controller;

import com.aarif1419.eduvault.Entity.Book;
import com.aarif1419.eduvault.Entity.BookDto;
import com.aarif1419.eduvault.Entity.UserBookMapping;
import com.aarif1419.eduvault.Service.UserBookMappingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user-books")
public class UserBookMappingController {

    @Autowired
    private UserBookMappingService userBookMappingService;
    

    // Get books by User's username
    @GetMapping("/user/{username}")
    public List<BookDto> getBooksByUsername(@PathVariable String username) {
        return userBookMappingService.getBooksByUsername(username);
    }

    // Get books by OAuthUser's username
    @GetMapping("/oauth-user/{username}")
    public List<BookDto> getBooksByOauthUsername(@PathVariable String username) {
        return userBookMappingService.getBooksByOauthUsername(username);
    }

    @PostMapping("/user/{username}/add-book/{bookId}")
    public ResponseEntity<String> addBookToUser(@PathVariable String username, @PathVariable Long bookId) {
        return userBookMappingService.addBookToUser(username, bookId);
    }

    // Add a book to an OAuthUser
    @PostMapping("/oauth-user/{username}/add-book/{bookId}")
    public ResponseEntity<String> addBookToOauthUser(@PathVariable String username, @PathVariable Long bookId) {
        return userBookMappingService.addBookToOauthUser(username, bookId);
    }

    @DeleteMapping("/delete-for-user/{username}/{bookId}")
    public ResponseEntity<String> deleteBookForUser(
            @PathVariable String username, 
            @PathVariable Long bookId) {
        userBookMappingService.deleteBookForUser(username, bookId);
        return ResponseEntity.ok("Book deleted for user: " + username);
    }

    // Endpoint to delete book for an OAuth user
    @DeleteMapping("/delete-for-oauth-user/{username}/{bookId}")
    public ResponseEntity<String> deleteBookForOauthUser(
            @PathVariable String username, 
            @PathVariable Long bookId) {
        userBookMappingService.deleteBookForOauthUser(username, bookId);
        return ResponseEntity.ok("Book deleted for OAuth user: " + username);
    }

    @GetMapping("/all-user-books")
    public ResponseEntity<List<UserBookMapping>> getAllUserBookMappings() {
        List<UserBookMapping> userBookMappings = userBookMappingService.getAllUserBookMappings();
        return ResponseEntity.ok(userBookMappings);
    }

    @GetMapping("/all-oauth-user-books")
    public ResponseEntity<List<UserBookMapping>> getAllOauthUserBookMappings() {
        List<UserBookMapping> oauthUserBookMappings = userBookMappingService.getAllOauthUserBookMappings();
        return ResponseEntity.ok(oauthUserBookMappings);
    }
}
