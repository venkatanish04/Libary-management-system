package com.aarif1419.eduvault.Service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import javax.crypto.SecretKey;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpSession;

@Service
public class OAuthService {
    private final String clientId = "359227723391-nrq9fbeh523sr06epqi1el5jjsnl3du3.apps.googleusercontent.com"; // Set your client ID from properties
    private final String clientSecret = "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"; // Set your client secret from properties
    private final String redirectUri = "http://localhost:8080/oauth/callback"; // Update as needed
    private final String scope = "email";

    public String getAuthorizationUrl() {
        return String.format(
            "https://accounts.google.com/o/oauth2/v2/auth?client_id=%s&redirect_uri=%s&response_type=code&scope=%s",
            clientId, redirectUri, scope
        );
    }

    public String handleCallback(String code,HttpSession session) throws IOException, InterruptedException {
        String accessToken = exchangeCodeForToken(code);
        String email = getEmailFromToken(accessToken,session);        
        return generateJwtToken(email);
    }


    private String exchangeCodeForToken(String code) throws IOException, InterruptedException {
        String url = "https://oauth2.googleapis.com/token";
        String body = String.format("code=%s&client_id=%s&client_secret=%s&redirect_uri=%s&grant_type=authorization_code",
                code, clientId, clientSecret, redirectUri);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        JSONObject jsonResponse = new JSONObject(response.body());
        return jsonResponse.getString("access_token");
    }

    private String getEmailFromToken(String accessToken,HttpSession session) throws IOException, InterruptedException {
        String url = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + accessToken;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        System.out.println();
        System.out.println();
        System.out.println(response);
        System.out.println(response.body());
        System.out.println();
        System.out.println();
        System.out.println();
        JSONObject jsonResponse = new JSONObject(response.body());
        String email = jsonResponse.getString("email");
        try{
        session.setAttribute("name",jsonResponse.getString("name"));
        }
        catch(Exception e){
            session.setAttribute("name", null);
        }
        session.setAttribute("picture",jsonResponse.getString("picture"));
        session.setAttribute("email", email);
        
        return email;
    }

    private static final byte[] SECRET_KEY = "Source@123456789101112131415161718".getBytes();

    private String generateJwtToken(String email) {
        SecretKey secretKey = Keys.hmacShaKeyFor(SECRET_KEY);

        return Jwts.builder()
            .subject(email)
            .issuedAt(new Date())
            .expiration(Date.from(Instant.now().plus(1, ChronoUnit.DAYS)))
            .signWith(secretKey)
            .compact();
    }

    
}
