package com.aarif1419.eduvault.Entity;

// import com.aarif1419.eduvault.Entity.Role;
import lombok.Data;

@Data
public class UserDataResponse {
    private String name;
    private String username;
    private String picture;
    private Role role;

    public UserDataResponse(String name, String username, String picture, Role role) {
        this.name = name;
        this.username = username;
        this.picture = picture;
        this.role = role;
    }
}
