package com.aarif1419.eduvault.Service;

import com.aarif1419.eduvault.Entity.Book;
import com.aarif1419.eduvault.Entity.BookDto;
import com.aarif1419.eduvault.Entity.OauthUsers;
import com.aarif1419.eduvault.Entity.User;
import com.aarif1419.eduvault.Entity.UserBookMapping;
import com.aarif1419.eduvault.Repository.UserBookMappingRepository;
import com.aarif1419.eduvault.Repository.UserRepository;
import com.aarif1419.eduvault.Repository.BookRepository;
import com.aarif1419.eduvault.Repository.OauthUsersRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserBookMappingService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OauthUsersRepository oauthUsersRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserBookMappingRepository userBookMappingRepository;

    // Add a book to a User
    public ResponseEntity<String> addBookToUser(String username, Long bookId) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("User not found with username: " + username);
        }
        Book book = bookRepository.findById(bookId)
                                    .orElseThrow(() -> new IllegalArgumentException("Book not found with ID: " + bookId));

        UserBookMapping mapping = new UserBookMapping();
        mapping.setUser(user);
        mapping.setBook(book);
        try {
            userBookMappingRepository.save(mapping);
            return ResponseEntity.ok("Book added to the user");
        } catch (Exception e) {
            // throw new IllegalArgumentException("Book already added to the user");
            return ResponseEntity.ok("Book already added to the user");
        }
    }

    // Add a book to an OAuthUser
    public ResponseEntity<String> addBookToOauthUser(String username, Long bookId) {
        OauthUsers oauthUser = oauthUsersRepository.findByUsername(username);
        if (oauthUser == null) {
            throw new IllegalArgumentException("OAuth User not found with username: " + username);
        }
        Book book = bookRepository.findById(bookId)
                                    .orElseThrow(() -> new IllegalArgumentException("Book not found with ID: " + bookId));

        UserBookMapping mapping = new UserBookMapping();
        mapping.setOauthUser(oauthUser);
        mapping.setBook(book);

        try {
            userBookMappingRepository.save(mapping);
            return ResponseEntity.ok("Book added to the OAuth user");
        } catch (Exception e) {
            // throw new IllegalArgumentException("Book already added to the OAuth user");
            return ResponseEntity.ok("Book already added to the OAuth user");
        }
    }

    public List<BookDto> getBooksByUsername(String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("User not found with username: " + username);
        }
        List<UserBookMapping> mappings = userBookMappingRepository.findByUser(user);
        return mappings.stream()
                    .map(mapping -> {
                        Book book = mapping.getBook();
                        return new BookDto(book.getId(), book.getTitle(), book.getAuthor(), book.getPdfUrl(),book.getDescription(), 
                                                book.getCategory(), book.getImg());
                    })
                    .collect(Collectors.toList());
    }


    // Fetch books by OAuthUser's username
    public List<BookDto> getBooksByOauthUsername(String username) {
        OauthUsers oauthUser = oauthUsersRepository.findByUsername(username);
        if (oauthUser == null) {
            throw new IllegalArgumentException("OAuth User not found with username: " + username);
        }
        List<UserBookMapping> mappings = userBookMappingRepository.findByOauthUser(oauthUser);
        return mappings.stream()
                    .map(mapping -> {
                        Book book = mapping.getBook();
                        return new BookDto(book.getId(), book.getTitle(), book.getAuthor(), book.getPdfUrl(),book.getDescription(), 
                                                book.getCategory(), book.getImg());
                    })
                    .collect(Collectors.toList());
    }


    public void deleteBookForUser(String username, Long bookId) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("User not found with username: " + username);
        }

        Book book = bookRepository.findById(bookId).orElseThrow(() -> 
            new IllegalArgumentException("Book not found with ID: " + bookId)
        );

        UserBookMapping mapping = userBookMappingRepository.findByUserAndBook(user, book)
            .orElseThrow(() -> new IllegalArgumentException("Mapping not found for user and book"));

        userBookMappingRepository.delete(mapping);
    }

    // Delete book for an OAuth user
    public void deleteBookForOauthUser(String username, Long bookId) {
        OauthUsers oauthUser = oauthUsersRepository.findByUsername(username);
        if (oauthUser == null) {
            throw new IllegalArgumentException("OAuth User not found with username: " + username);
        }

        Book book = bookRepository.findById(bookId).orElseThrow(() -> 
            new IllegalArgumentException("Book not found with ID: " + bookId)
        );

        UserBookMapping mapping = userBookMappingRepository.findByOauthUserAndBook(oauthUser, book)
            .orElseThrow(() -> new IllegalArgumentException("Mapping not found for OAuth user and book"));

        userBookMappingRepository.delete(mapping);
    }

    public List<UserBookMapping> getAllUserBookMappings() {
        return userBookMappingRepository.findAll(); // Assuming UserBookMappingRepository handles this
    }

    // Get all user-book mappings for OAuth users
    public List<UserBookMapping> getAllOauthUserBookMappings() {
        return userBookMappingRepository.findAll(); // Modify if you need OAuth-specific logic
    }

}
