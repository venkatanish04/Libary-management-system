package com.aarif1419.eduvault.Entity; // Adjust the package as necessary

public enum Role {
    STUDENT, EDUCATOR, RESEARCHER, ADMIN ,GUEST,Educator,Researcher,Admin,Guest,Student
}
