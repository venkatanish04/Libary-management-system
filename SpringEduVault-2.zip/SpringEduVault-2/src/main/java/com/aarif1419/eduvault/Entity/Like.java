package com.aarif1419.eduvault.Entity;

import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.persistence.Id;

@Document(collection = "likes")
public class Like {
 
    @Id
    private String id;
    private int count;

    public Like(String id, int count) {

        this.id = id;

        this.count = count;

    }
 
    // Getters and setters
    public String getId() {
        return id;
    }
 
    public void setId(String id) {
        this.id = id;
    }
 
    public int getCount() {
        return count;
    }
 
    public void setCount(int count) {
        this.count = count;
    }
}
