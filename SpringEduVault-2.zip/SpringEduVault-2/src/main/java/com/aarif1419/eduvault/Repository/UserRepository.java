package com.aarif1419.eduvault.Repository;

import org.springframework.data.repository.CrudRepository;

import com.aarif1419.eduvault.Entity.User;


public interface UserRepository extends CrudRepository<User, Integer> {
    User findByEmail(String email);
    User findByUsername(String username);

}

