package com.aarif1419.eduvault.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import com.mongodb.client.result.UpdateResult;
import org.springframework.stereotype.Service;

import com.aarif1419.eduvault.Entity.Like;

@Service
public class LikeCountService {
 
    @Autowired
    private MongoTemplate mongoTemplate;
 
    public int incrementLikeCount() {
        try {
            Query query = Query.query(Criteria.where("_id").is("likeCount"));
            Update update = new Update().inc("count", 1);
            UpdateResult result = mongoTemplate.updateFirst(query, update, Like.class);
            if (result.getMatchedCount() == 0) {
                Like likeCount = new Like("likeCount", 1);
                mongoTemplate.save(likeCount);
                return 1;
            }
            Like likeCount = mongoTemplate.findById("likeCount", Like.class);
            return likeCount != null ? likeCount.getCount() : 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
 
    public int getLikeCount() {
        try {
            Like likeCount = mongoTemplate.findById("likeCount", Like.class);
            return likeCount != null ? likeCount.getCount() : 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}