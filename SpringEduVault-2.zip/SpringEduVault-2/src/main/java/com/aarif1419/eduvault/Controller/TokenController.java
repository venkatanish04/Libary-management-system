package com.aarif1419.eduvault.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpSession;

import java.util.Map;
import java.util.HashMap;

import javax.crypto.SecretKey;

@RestController
public class TokenController {

    @GetMapping("/verify-token")
    @ResponseBody
    public ResponseEntity<Boolean> verifyToken(@RequestHeader("Authorization") String authorizationHeader) {
        String token = authorizationHeader.replace("Bearer ", "");
        try {
            SecretKey secretKey = Keys.hmacShaKeyFor("Source@123456789101112131415161718".getBytes());
            Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token);

            return ResponseEntity.ok(true);
        } catch (JwtException e) {
            return ResponseEntity.status(401).body(false);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(false);
        }
    }

    @GetMapping("/getjwt-token")
    public ResponseEntity<?> getToken(HttpSession session) {
        // Retrieve the JWT token from the session
        String jwtToken = (String) session.getAttribute("jwtToken");

        Map<String, Object> response = new HashMap<>();

        if (jwtToken != null) {
            // Add the token and userType to the response
            response.put("token", jwtToken);
            response.put("userType", session.getAttribute("userType"));
            response.put("registered", session.getAttribute("registered"));
            return ResponseEntity.ok(response);
        } else {
            response.put("error", "JWT token not found");
            return ResponseEntity.status(401).body(response);
        }
    }

    @GetMapping("/cuslogout")
    public ResponseEntity<String> logout(HttpSession session) {
         // This will destroy the session and remove all attributes
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("Session invalidated, user logged out.");
        System.out.println();
        System.out.println();
        System.out.println();
        session.invalidate();
        return ResponseEntity.ok("Session invalidated, user logged out.");
    }


}