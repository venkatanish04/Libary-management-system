package com.aarif1419.eduvault;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// import org.springframework.boot.autoconfigure.domain.EntityScan;


@SpringBootApplication
public class EduvaultApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduvaultApplication.class, args);
	}
}

// @SpringBootApplication(scanBasePackages = "com.aarif1419.eduvault")
// @EntityScan(basePackages = "com.aarif1419.eduvault.Entity")
// public class EduvaultApplication {
//     public static void main(String[] args) {
//         SpringApplication.run(EduvaultApplication.class, args);
//     }
// }
