package com.aarif1419.eduvault.Controller;

import java.util.Date;
import java.util.Map;
import java.util.stream.Collectors;
import com.aarif1419.eduvault.Entity.UserDataResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.time.Instant;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.core.AuthenticationException;
import com.aarif1419.eduvault.Entity.Role;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.aarif1419.eduvault.Entity.User;
// import com.aarif1419.eduvault.Entity.User.Role;
import com.aarif1419.eduvault.Repository.OauthUsersRepository;
import com.aarif1419.eduvault.Repository.UserRepository;
import java.util.HashMap;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpSession;

import javax.crypto.SecretKey;

import java.time.temporal.ChronoUnit;

import com.aarif1419.eduvault.Entity.CustomUserDetails;
// import com.aarif1419.eduvault.Entity.JwtResponse;
import com.aarif1419.eduvault.Entity.LoginRequest;
import com.aarif1419.eduvault.Entity.OauthUsers;



@Controller
@RequestMapping(path="/db")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
    private JwtDecoder jwtDecoder;


	@Autowired
    private PasswordEncoder passwordEncoder;

	@Autowired
    private OauthUsersRepository oauthUserRepository;

	@Autowired
    private AuthenticationManager authenticationManager;

	@PostMapping("/login")
    @ResponseBody
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
            );
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = generateJwtToken(authentication);
			Map<String, Object> response = new HashMap<>();
			response.put("token", jwt);
            response.put("userType", "user");
            response.put("registered", true);
            return ResponseEntity.ok(response);
        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
	
	private static final byte[] SECRET_KEY = "Source@123456789101112131415161718".getBytes();

	private String generateJwtToken(Authentication authentication) {
		CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
		User user = userDetails.getUser();
		String authorities = authentication.getAuthorities().stream()
				.map(GrantedAuthority::getAuthority)
				.collect(Collectors.joining(","));
		
		SecretKey secretKey = Keys.hmacShaKeyFor(SECRET_KEY);

		String jwt = Jwts.builder()
				.subject(user.getUsername())
				.claim("authorities", authorities)
				.issuedAt(new Date())
				.expiration(Date.from(Instant.now().plus(1, ChronoUnit.DAYS)))
				.signWith(secretKey)
            	.compact();
	
		return jwt;
	}

	// @PostMapping(path = "/add")
	// @ResponseBody
	// public String addNewUser(
	// 	@RequestParam String username,
	// 	@RequestParam String name,
	// 	@RequestParam String email,
	// 	@RequestParam String password,
	// 	@RequestParam String institution,
	// 	@RequestParam String department,
	// 	@RequestParam String picture,
	// 	@RequestParam Role role
	// ) {
	// 	try {
	// 		User newUser = new User();
	// 		newUser.setUsername(username);
	// 		newUser.setEmail(email);
	// 		newUser.setName(name);
	// 		newUser.setRole(role);
	// 		newUser.setInstitution(institution);
	// 		newUser.setDept(department);
	// 		newUser.setPicture(picture);

	// 		// Hash the password using BCrypt
	// 		String hashedPassword = passwordEncoder.encode(password);
	// 		newUser.setPassword(hashedPassword);

	// 		userRepository.save(newUser);

	// 		return "Inserted";
	// 	} catch (Exception e) {
	// 		return e.getMessage();
	// 	}
	// }

	@PostMapping(path = "/add")
@ResponseBody
public ResponseEntity<String> addNewUser(
    @RequestParam String username,
    @RequestParam String name,
    @RequestParam String email,
    @RequestParam String password,
    @RequestParam String institution,
    @RequestParam String department,
    @RequestParam String picture,
    @RequestParam Role role
) {
    try {
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setEmail(email);
        newUser.setName(name);
        newUser.setRole(role);
        newUser.setInstitution(institution);
        newUser.setDept(department);
        newUser.setPicture(picture);

        // Hash the password using BCrypt
        String hashedPassword = passwordEncoder.encode(password);
        newUser.setPassword(hashedPassword);

        userRepository.save(newUser);

        return ResponseEntity.status(HttpStatus.CREATED).body("Inserted");
    } catch (DataIntegrityViolationException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Data Integrity Error: " + e.getMessage());
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error: " + e.getMessage());
    }
}


	@PostMapping(path = "/addOauth")
	@ResponseBody
	public String addNewOauthUser(
		@RequestParam String username,
		@RequestParam String name,
		@RequestParam String email,
		// @RequestParam String password,
		@RequestParam String institution,
		@RequestParam String department,
		@RequestParam String picture,
		@RequestParam Role role
	) {
		try {
			OauthUsers newUser = new OauthUsers();
			newUser.setUsername(username);
			newUser.setEmail(email);
			newUser.setName(name);
			newUser.setRole(role);
			newUser.setInstitution(institution);
			newUser.setDept(department);
			newUser.setPicture(picture);

			// Hash the password using BCrypt
			// String hashedPassword = passwordEncoder.encode(password);
			// newUser.setPassword(hashedPassword);

			oauthUserRepository.save(newUser);

			return "Inserted";
		} catch (Exception e) {
			return "Error inserting user: " + e.getMessage();
		}
	}

	@GetMapping(path="/all")
	public @ResponseBody Iterable<User> getAllUsers() {
		// This returns a JSON or XML with the users
		return userRepository.findAll();
	}

	@GetMapping(path="/allOauth")
	public @ResponseBody Iterable<OauthUsers> getAllOauthUsers() {
		// This returns a JSON or XML with the users
		return oauthUserRepository.findAll();
	}

	@GetMapping("/userdata")
	@ResponseBody
	public ResponseEntity<UserDataResponse> getUserData(@RequestHeader("Authorization") String token) {
		String tokenValue = token.replace("Bearer ", "");
		
		try {
			// Decode JWT token
			String username = jwtDecoder.decode(tokenValue).getSubject();
			
			// Try to find the user (for normal login users)
			User user = userRepository.findByUsername(username);

			// If user is found (normal user), return their data
			if (user != null) {
				UserDataResponse response = new UserDataResponse(
					user.getName(),
					user.getUsername(),
					user.getPicture(),
					user.getRole()
				);
				return ResponseEntity.ok(response);
			} 
			
			// If the user was not found in the normal flow, handle OAuth users
			OauthUsers oauthUser = oauthUserRepository.findByEmail(username); // Assuming 'username' is the email in OAuth
			if (oauthUser != null) {
				UserDataResponse response = new UserDataResponse(
					oauthUser.getName(),
					oauthUser.getUsername(),
					oauthUser.getPicture(),
					oauthUser.getRole()
				);
				return ResponseEntity.ok(response);
			}
			UserDataResponse errorResponse = new UserDataResponse("User not found", "", "",Role.Guest);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
			
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
	}

	@GetMapping("/sendOauthUser")
	@ResponseBody
	public ResponseEntity<Map<String,Object>> sendOauthUserData(HttpSession session) {
		try {
			Map<String, Object> response = new HashMap<>();
			response.put("name", session.getAttribute("name"));
			response.put("email", session.getAttribute("email"));
			response.put("picture", session.getAttribute("picture"));
			return ResponseEntity.ok(response);
			
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
	}

	@GetMapping("/deleteUser")
	@ResponseBody
	public ResponseEntity<String> deleteUser(@RequestParam String username) {
		try {
			User user = userRepository.findByUsername(username);
			if (user != null) {
				userRepository.delete(user);
				return ResponseEntity.ok("User deleted");
			}
			OauthUsers oauthUser = oauthUserRepository.findByUsername(username);
			if (oauthUser != null) {
				oauthUserRepository.delete(oauthUser);
				return ResponseEntity.ok("OAuth User deleted");
			}
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error: " + e.getMessage());
		}
	}
}

