package com.aarif1419.eduvault.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.core.io.ByteArrayResource;
// import org.springframework.core.io.InputStreamResource;

import java.io.InputStream;
import java.net.URL;
import java.io.IOException;
import java.net.HttpURLConnection;

@RestController
public class FileDownloadController {

    @GetMapping("/download")
    public ResponseEntity<ByteArrayResource> downloadFile(@RequestParam String fileId, @RequestParam String fileName) throws IOException {
        
        // Google Drive direct download URL
        String downloadUrl = "https://drive.google.com/uc?export=download&id=" + fileId;

        // Open a connection to the Google Drive file
        URL url = new URL(downloadUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        // Check for successful connection
        if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new IOException("Failed to fetch file from Google Drive");
        }

        // Get the InputStream of the file
        InputStream inputStream = connection.getInputStream();

        // Create a ByteArrayResource from the InputStream
        ByteArrayResource resource = new ByteArrayResource(inputStream.readAllBytes());

        // Set the response headers and return the file with the custom filename
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + ".pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(resource.contentLength())
                .body(resource);
    }
}

