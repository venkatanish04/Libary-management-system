package com.aarif1419.eduvault.Controller;

import com.aarif1419.eduvault.Entity.OauthUsers;
import com.aarif1419.eduvault.Repository.OauthUsersRepository;
import com.aarif1419.eduvault.Service.OAuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.servlet.view.RedirectView;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@RestController
public class OAuthController {
    private final OAuthService oauthService;

    @Autowired
    private OauthUsersRepository oauthUserRepository;

    
	@Autowired
    private JwtDecoder jwtDecoder;

    public OAuthController(OAuthService oauthService) {
        this.oauthService = oauthService;
    }

    @GetMapping("/")
    public RedirectView home() {
        RedirectView redirectView = new RedirectView();
        redirectView.setUrl("http://localhost:5173/eduvault-deploy/");
        return redirectView;
    }

    @GetMapping("/oauth/login")
    public void login(HttpServletResponse response) throws IOException {
        String authUrl = oauthService.getAuthorizationUrl();
        response.sendRedirect(authUrl);
    }



    @GetMapping("/oauth/callback")
    public RedirectView callback(@RequestParam String code, HttpSession session) throws IOException, InterruptedException {
        String jwtToken = oauthService.handleCallback(code,session);
        
        String userType ="Oauth";
        String username = jwtDecoder.decode(jwtToken).getSubject();
        OauthUsers oauthUser = oauthUserRepository.findByEmail(username);
        Boolean regisBoolean = true;
        if(oauthUser == null){
            regisBoolean = false;
        }
        
        // Save the token in the session
        session.setAttribute("jwtToken", jwtToken);
        session.setAttribute("userType",userType );
        session.setAttribute("registered",regisBoolean );
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("jwtToken  "+ jwtToken);
        System.out.println("userType  "+userType );
        System.out.println("registered  "+regisBoolean );
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();   
        
        // Redirect to the frontend without exposing the JWT token
        RedirectView redirectView = new RedirectView();
        redirectView.setUrl("http://localhost:5173/eduvault-deploy/callback");
        return redirectView;
    }


}

