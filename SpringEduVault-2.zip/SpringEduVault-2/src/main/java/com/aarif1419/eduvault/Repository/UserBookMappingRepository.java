package com.aarif1419.eduvault.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aarif1419.eduvault.Entity.Book;
import com.aarif1419.eduvault.Entity.OauthUsers;
import com.aarif1419.eduvault.Entity.User;
import com.aarif1419.eduvault.Entity.UserBookMapping;

@Repository
public interface UserBookMappingRepository extends JpaRepository<UserBookMapping, Long> {

    Optional<UserBookMapping> findByUserAndBook(User user, Book book);

    // Find mapping by OAuthUser and book
    Optional<UserBookMapping> findByOauthUserAndBook(OauthUsers oauthUser, Book book);

    // Find books by User
    List<UserBookMapping> findByUser(User user);

    // Find books by OAuthUser
    List<UserBookMapping> findByOauthUser(OauthUsers oauthUser);
}
