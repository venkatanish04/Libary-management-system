package com.aarif1419.eduvault.Service;

import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageRequest;
// import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.aarif1419.eduvault.Entity.Book;
import com.aarif1419.eduvault.Entity.OauthUsers;
import com.aarif1419.eduvault.Entity.User;
import com.aarif1419.eduvault.Entity.UserBookMapping;
import com.aarif1419.eduvault.Repository.BookRepository;
import com.aarif1419.eduvault.Repository.UserBookMappingRepository;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // @Autowired
    // private UserBookMappingRepository userBookMappingRepository;

    // public List<Book> getBooksForUser(User user) {
    //     return userBookMappingRepository.findByUser(user).stream()
    //                                     .map(UserBookMapping::getBook)
    //                                     .collect(Collectors.toList());
    // }

    // public List<Book> getBooksForOAuthUser(OauthUsers oauthUser) {
    //     return userBookMappingRepository.findByOauthUser(oauthUser).stream()
    //                                     .map(UserBookMapping::getBook)
    //                                     .collect(Collectors.toList());
    // }

    public Book addBook(Book book) {
        return bookRepository.save(book);  // Saves the book and returns the saved entity
    }
    
    public List<Book> addBulkBook(List<Book> books) {
        return bookRepository.saveAll(books);  // Saves the books and returns the saved entities
    }

    public Book updateBook(Long id, Book updatedBook) {
        Optional<Book> existingBook = bookRepository.findById(id);
        if (existingBook.isPresent()) {
            Book book = existingBook.get();
            book.setTitle(updatedBook.getTitle());
            book.setAuthor(updatedBook.getAuthor());
            book.setDescription(updatedBook.getDescription());
            book.setCategory(updatedBook.getCategory());
            book.setImg(updatedBook.getImg());
            book.setPdfUrl(updatedBook.getPdfUrl());
            return bookRepository.save(book);  // Save the updated book and return it
        } else {
            throw new RuntimeException("Book not found with id: " + id);  // Handle book not found scenario
        }
    }

    public void deleteBook(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
        } else {
            throw new RuntimeException("Book not found with id: " + id);  // Handle case when book is not found
        }
    }


    public List<Book> findBooks(String title, String category) {
        if (title != null && !title.isEmpty() && category != null && !category.isEmpty()) {
            return bookRepository.findByTitleContainingAndCategory(title, category);
        } else if (title != null && !title.isEmpty()) {
            return bookRepository.findByTitleContaining(title);
        } else if (category != null && !category.isEmpty()) {
            return bookRepository.findByCategory(category);
        } else {
            return bookRepository.findAll();
        }
    }
}

